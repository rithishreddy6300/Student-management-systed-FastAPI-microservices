const API_URL = (import.meta.env.VITE_API_URL || "http://localhost:8000").replace(/\/$/, "");
const TOKEN_KEY = "campusdesk_access_token";

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const saveToken = (token) => localStorage.setItem(TOKEN_KEY, token);
export const clearToken = () => localStorage.removeItem(TOKEN_KEY);

export async function apiRequest(path, options = {}) {
  const headers = new Headers(options.headers || {});
  if (options.body && !(options.body instanceof FormData)) {
    headers.set("Content-Type", "application/json");
  }
  const token = getToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);

  let response;
  try {
    response = await fetch(`${API_URL}${path}`, { ...options, headers });
  } catch {
    throw new Error("Could not reach the API gateway. Check that the backend services are running.");
  }

  if (response.status === 204) return null;
  const contentType = response.headers.get("content-type") || "";
  const payload = contentType.includes("application/json")
    ? await response.json()
    : await response.text();
  if (!response.ok) {
    const detail = typeof payload === "object" && payload !== null ? payload.detail : payload;
    const message = typeof detail === "string"
      ? detail
      : Array.isArray(detail)
        ? detail.map((issue) => issue?.msg).filter((item) => typeof item === "string").join(" ") || `Request failed (${response.status}).`
        : `Request failed (${response.status}).`;
    const error = new Error(message);
    error.status = response.status;
    throw error;
  }
  return payload;
}

export const authApi = {
  register: (data) => apiRequest("/auth/register", { method: "POST", body: JSON.stringify(data) }),
  login: (data) => apiRequest("/auth/login", { method: "POST", body: JSON.stringify(data) }),
  me: () => apiRequest("/auth/me"),
};

export const studentApi = {
  list: () => apiRequest("/students"),
  create: (data) => apiRequest("/students", { method: "POST", body: JSON.stringify(data) }),
  update: (id, data) => apiRequest(`/students/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  remove: (id) => apiRequest(`/students/${id}`, { method: "DELETE" }),
};

export const courseApi = {
  list: () => apiRequest("/courses"),
  create: (data) => apiRequest("/courses", { method: "POST", body: JSON.stringify(data) }),
  update: (id, data) => apiRequest(`/courses/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  remove: (id) => apiRequest(`/courses/${id}`, { method: "DELETE" }),
  enroll: (courseId, studentId) =>
    apiRequest(`/courses/${courseId}/students/${studentId}`, { method: "POST" }),
  enrollments: (courseId) => apiRequest(`/courses/${courseId}/students`),
};
