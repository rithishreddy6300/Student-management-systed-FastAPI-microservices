import { useEffect, useState } from "react";
import { Navigate, Route, Routes, useNavigate } from "react-router-dom";
import AppLayout from "./components/AppLayout.jsx";
import AuthPages from "./pages/AuthPages.jsx";
import Courses from "./pages/Courses.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Students from "./pages/Students.jsx";
import { authApi, clearToken, getToken, saveToken } from "./services/api.js";

function AuthRoute({ mode, onAuthenticated }) {
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  const submit = async (form) => {
    setError("");
    setBusy(true);
    try {
      const response = mode === "register" ? await authApi.register(form) : await authApi.login(form);
      saveToken(response.access_token);
      onAuthenticated(response.user);
      navigate("/", { replace: true });
    } catch (err) { setError(err.message); }
    finally { setBusy(false); }
  };
  return <AuthPages mode={mode} onSubmit={submit} busy={busy} error={error} />;
}

export default function App() {
  const [user, setUser] = useState(null);
  const [checking, setChecking] = useState(true);
  const [sessionError, setSessionError] = useState("");
  const verifySession = () => {
    setChecking(true);
    setSessionError("");
    if (!getToken()) { setChecking(false); return; }
    authApi.me()
      .then(setUser)
      .catch((error) => {
        if (error.status === 401) {
          clearToken();
          setUser(null);
        } else {
          setSessionError(error.message);
        }
      })
      .finally(() => setChecking(false));
  };
  useEffect(() => {
    verifySession();
  }, []);
  const logout = () => { clearToken(); setUser(null); setSessionError(""); };
  if (checking) return <div className="screen-loading">Opening your workspace…</div>;
  if (sessionError) return <main className="screen-error"><div><span className="eyebrow">CAMPUSDESK</span><h1>Workspace unavailable</h1><p>{sessionError}</p><button className="button button-primary" onClick={verifySession}>Try again</button><button className="button button-quiet" onClick={logout}>Sign out</button></div></main>;
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <AuthRoute mode="login" onAuthenticated={setUser} />} />
      <Route path="/register" element={user ? <Navigate to="/" replace /> : <AuthRoute mode="register" onAuthenticated={setUser} />} />
      <Route element={user ? <AppLayout user={user} onLogout={logout} /> : <Navigate to="/login" replace />}>
        <Route index element={<Dashboard user={user} />} />
        <Route path="/students" element={<Students />} />
        <Route path="/courses" element={<Courses />} />
      </Route>
      <Route path="*" element={<Navigate to={user ? "/" : "/login"} replace />} />
    </Routes>
  );
}
