import { Outlet, useLocation } from "react-router-dom";
import Sidebar from "./Sidebar.jsx";

const pageNames = { "/": "Overview", "/students": "Students", "/courses": "Courses" };

export default function AppLayout({ user, onLogout }) {
  const location = useLocation();
  const title = pageNames[location.pathname] || "Workspace";
  return (
    <div className="app-shell">
      <Sidebar user={user} onLogout={onLogout} />
      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumb">Workspace <span>/</span> <strong>{title}</strong></div>
          <div className="topbar-actions"><div className="topbar-avatar">{user?.name?.slice(0, 1).toUpperCase()}</div></div>
        </header>
        <div className="page-content"><Outlet /></div>
      </main>
    </div>
  );
}
