import { BookOpen, GraduationCap, LayoutDashboard, LogOut, Users } from "lucide-react";
import { NavLink } from "react-router-dom";

const links = [
  { to: "/", label: "Overview", icon: LayoutDashboard, end: true },
  { to: "/students", label: "Students", icon: Users },
  { to: "/courses", label: "Courses", icon: BookOpen },
];

export default function Sidebar({ user, onLogout }) {
  return (
    <aside className="sidebar">
      <NavLink className="brand" to="/">
        <span className="brand-mark"><GraduationCap size={21} /></span>
        <span>Campus<span className="brand-light">Desk</span></span>
      </NavLink>
      <div className="nav-caption">WORKSPACE</div>
      <nav className="nav-links" aria-label="Main navigation">
        {links.map(({ to, label, icon: Icon, end }) => (
          <NavLink key={to} to={to} end={end} className={({ isActive }) => `nav-link${isActive ? " active" : ""}`}>
            <Icon size={18} strokeWidth={1.8} />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>
      <div className="sidebar-bottom">
        <div className="profile">
          <div className="avatar">{user?.name?.slice(0, 1).toUpperCase()}</div>
          <div className="profile-copy"><strong>{user?.name}</strong><span>Administrator</span></div>
        </div>
        <button className="logout-button" onClick={onLogout}><LogOut size={17} /><span>Sign out</span></button>
        <div className="sidebar-footnote">CAMPUSDESK <span>•</span> STUDENT PORTAL</div>
      </div>
    </aside>
  );
}
