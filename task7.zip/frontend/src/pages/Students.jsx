import { useCallback, useEffect, useState } from "react";
import { Pencil, Plus, Search, Trash2, Users } from "lucide-react";
import Modal from "../components/Modal.jsx";
import { studentApi } from "../services/api.js";

const EMPTY = { name: "", email: "", phone: "", department: "", course: "" };
const fields = [
  ["name", "Full name", "e.g. Avery Morgan", "text"],
  ["email", "Email address", "avery@university.edu", "email"],
  ["phone", "Phone number", "+1 555 010 2040", "tel"],
  ["department", "Department", "e.g. Computer Science", "text"],
  ["course", "Course", "e.g. BSc Computer Science", "text"],
];

export default function Students() {
  const [students, setStudents] = useState([]);
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState(null);
  const [formOpen, setFormOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try { setStudents(await studentApi.list()); setError(""); }
    catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const openForm = (student = null) => {
    setFormOpen(true);
    setEditing(student);
    setForm(student ? Object.fromEntries(Object.keys(EMPTY).map((key) => [key, student[key]])) : EMPTY);
    setError("");
  };
  const submit = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      if (editing) await studentApi.update(editing.id, form);
      else await studentApi.create(form);
      setFormOpen(false);
      setEditing(null);
      await load();
    } catch (err) { setError(err.message); }
    finally { setSaving(false); }
  };
  const remove = async (student) => {
    if (!window.confirm(`Delete ${student.name} from the student directory?`)) return;
    try { await studentApi.remove(student.id); await load(); }
    catch (err) { setError(err.message); }
  };
  const filtered = students.filter((student) => Object.values(student).join(" ").toLowerCase().includes(search.toLowerCase()));

  return (
    <>
      <div className="page-heading"><div><span className="eyebrow">CAMPUS DIRECTORY</span><h1>Students <span className="count-pill">{students.length}</span></h1><p>Keep every student detail organized in one place.</p></div><button className="button button-primary" onClick={() => openForm()}><Plus size={17} /> Add student</button></div>
      {error && <div className="alert error-alert" role="alert">{error}</div>}
      <section className="panel directory-panel">
        <div className="directory-toolbar"><div><strong>All students</strong><span>{loading ? "Loading…" : `${filtered.length} ${filtered.length === 1 ? "record" : "records"}`}</span></div><label className="table-search"><Search size={16} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search students..." /></label></div>
        {loading ? <p className="muted-state">Loading student records…</p> : filtered.length === 0 ? <div className="empty-state"><span className="empty-icon"><Users size={20} /></span><strong>{search ? "No matching students" : "No students yet"}</strong><p>{search ? "Try another name, email, course or department." : "Add a student to start building your directory."}</p>{!search && <button className="button button-secondary" onClick={() => openForm()}><Plus size={15} /> Add student</button>}</div> : (
          <div className="table-wrap"><table><thead><tr><th>STUDENT</th><th>PHONE</th><th>DEPARTMENT</th><th>COURSE</th><th className="actions-heading">ACTIONS</th></tr></thead><tbody>{filtered.map((student) => <tr key={student.id}><td><span className="student-name-cell"><span className="small-avatar">{student.name.slice(0, 1).toUpperCase()}</span><span><strong>{student.name}</strong><small>{student.email}</small></span></span></td><td>{student.phone}</td><td>{student.department}</td><td><span className="tag">{student.course}</span></td><td><div className="row-actions"><button onClick={() => openForm(student)} aria-label={`Edit ${student.name}`}><Pencil size={15} /></button><button className="danger-action" onClick={() => remove(student)} aria-label={`Delete ${student.name}`}><Trash2 size={15} /></button></div></td></tr>)}</tbody></table></div>
        )}
      </section>
      {formOpen && <Modal title={editing ? "Edit student" : "Add a student"} onClose={() => setFormOpen(false)}>
        <form className="data-form" onSubmit={submit}>
          {fields.map(([key, label, placeholder, type]) => <label key={key}>{label}<input type={type} value={form[key]} onChange={(event) => setForm({ ...form, [key]: event.target.value })} placeholder={placeholder} required maxLength={key === "email" ? 254 : key === "name" ? 120 : key === "phone" ? 30 : key === "department" ? 100 : 120} /></label>)}
          {error && <div className="alert error-alert" role="alert">{error}</div>}
          <div className="form-actions"><button type="button" className="button button-quiet" onClick={() => setFormOpen(false)}>Cancel</button><button className="button button-primary" disabled={saving}>{saving ? "Saving…" : editing ? "Save changes" : "Add student"}</button></div>
        </form>
      </Modal>}
    </>
  );
}
