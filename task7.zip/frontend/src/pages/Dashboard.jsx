import { useEffect, useState } from "react";
import { ArrowRight, BookOpen, GraduationCap, Plus, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { courseApi, studentApi } from "../services/api.js";

export default function Dashboard({ user }) {
  const [data, setData] = useState({ students: [], courses: [] });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const today = new Intl.DateTimeFormat("en", { weekday: "long" }).format(new Date()).toUpperCase();
  useEffect(() => {
    Promise.all([studentApi.list(), courseApi.list()])
      .then(([students, courses]) => setData({ students, courses }))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);
  return (
    <>
      <div className="welcome-row"><div><span className="eyebrow">{today} · YOUR CAMPUS AT A GLANCE</span><h1>Good morning, {user?.name?.split(" ")[0]} <span className="wave">✳</span></h1><p>Here’s what’s happening across your workspace today.</p></div><Link className="button button-primary" to="/students"><Plus size={17} /> Add a student</Link></div>
      {error && <div className="alert error-alert" role="alert">{error}</div>}
      <section className="stats-grid">
        <article className="stat-card"><div className="stat-top"><span>Total students</span><span className="stat-icon lavender"><Users size={19} /></span></div><div className="stat-value">{loading ? "—" : data.students.length}</div><div className="stat-foot"><span className="stat-dot green" /> Student records in your workspace</div></article>
        <article className="stat-card"><div className="stat-top"><span>Available courses</span><span className="stat-icon peach"><BookOpen size={19} /></span></div><div className="stat-value">{loading ? "—" : data.courses.length}</div><div className="stat-foot"><span className="stat-dot blue" /> Courses currently listed</div></article>
        <article className="stat-card stat-highlight"><div className="stat-top"><span>Workspace status</span><span className="stat-icon white-icon"><GraduationCap size={19} /></span></div><div className="status-value"><span className="status-pulse" /> All systems ready</div><div className="stat-foot">Your campus workspace is up to date</div></article>
      </section>
      <section className="dashboard-grid">
        <article className="panel recent-panel">
          <div className="panel-heading"><div><span className="eyebrow">YOUR DIRECTORY</span><h2>Recently added students</h2></div><Link to="/students" className="text-link">View all <ArrowRight size={15} /></Link></div>
          {loading ? <p className="muted-state">Loading students…</p> : data.students.length === 0 ? <div className="empty-state"><span className="empty-icon"><Users size={20} /></span><strong>Your student directory starts here</strong><p>Add your first student to bring your workspace to life.</p><Link to="/students" className="button button-secondary"><Plus size={15} /> Add student</Link></div> : <div className="table-wrap"><table><thead><tr><th>STUDENT</th><th>DEPARTMENT</th><th>COURSE</th></tr></thead><tbody>{data.students.slice(0, 5).map((student) => <tr key={student.id}><td><span className="student-name-cell"><span className="small-avatar">{student.name.slice(0, 1).toUpperCase()}</span><span><strong>{student.name}</strong><small>{student.email}</small></span></span></td><td>{student.department}</td><td>{student.course}</td></tr>)}</tbody></table></div>}
        </article>
        <article className="panel quick-panel">
          <span className="eyebrow">QUICK ACCESS</span><h2>Make it happen.</h2><p>Jump back into the things you do most.</p>
          <Link to="/students" className="quick-link"><span className="quick-icon lavender"><Users size={18} /></span><span><strong>Manage students</strong><small>Review and update your directory</small></span><ArrowRight size={16} /></Link>
          <Link to="/courses" className="quick-link"><span className="quick-icon peach"><BookOpen size={18} /></span><span><strong>Manage courses</strong><small>Organize courses and enrollments</small></span><ArrowRight size={16} /></Link>
        </article>
      </section>
    </>
  );
}
