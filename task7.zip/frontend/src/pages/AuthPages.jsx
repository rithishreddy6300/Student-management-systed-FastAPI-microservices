import { useState } from "react";
import { ArrowRight, GraduationCap } from "lucide-react";
import { Link } from "react-router-dom";

function AuthShell({ mode, onSubmit, busy, error }) {
  const isRegister = mode === "register";
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const update = (event) => setForm({ ...form, [event.target.name]: event.target.value });
  const submit = (event) => {
    event.preventDefault();
    onSubmit(form);
  };
  return (
    <main className="auth-page">
      <section className="auth-visual">
        <Link className="brand auth-brand" to="/login">
          <span className="brand-mark"><GraduationCap size={21} /></span>
          <span>Campus<span className="brand-light">Desk</span></span>
        </Link>
        <div className="visual-copy">
          <span className="eyebrow">YOUR CAMPUS, CONNECTED</span>
          <h1>Make room for<br /><em>what matters.</em></h1>
          <p>A calmer, clearer way to manage your students, courses and campus community.</p>
          <div className="visual-stats"><div><strong>01</strong><span>One connected workspace</span></div><div><strong>∞</strong><span>Room to grow together</span></div></div>
        </div>
        <div className="visual-footer">STUDENT MANAGEMENT, MADE SIMPLE <span>© 2026 CAMPUSDESK</span></div>
        <div className="visual-orb orb-one" /><div className="visual-orb orb-two" />
      </section>
      <section className="auth-form-panel">
        <div className="auth-form-wrap">
          <span className="eyebrow">{isRegister ? "GET STARTED" : "WELCOME BACK"}</span>
          <h2>{isRegister ? "Create your account" : "Sign in to your workspace"}</h2>
          <p className="auth-subtitle">{isRegister ? "Set up your administrator account to get started." : "Enter your details to access your dashboard."}</p>
          {error && <div className="alert error-alert" role="alert">{error}</div>}
          <form className="auth-form" onSubmit={submit}>
            {isRegister && <label>Full name<input name="name" value={form.name} onChange={update} placeholder="e.g. Jordan Lee" autoComplete="name" required minLength="1" maxLength="100" /></label>}
            <label>Email address<input name="email" type="email" value={form.email} onChange={update} placeholder="you@university.edu" autoComplete="email" required /></label>
            <label>Password<input name="password" type="password" value={form.password} onChange={update} placeholder={isRegister ? "At least 8 characters" : "Enter your password"} autoComplete={isRegister ? "new-password" : "current-password"} required minLength={isRegister ? 8 : 1} maxLength="128" /></label>
            <button className="button button-primary auth-submit" disabled={busy}>{busy ? "Please wait..." : isRegister ? "Create account" : "Sign in"} {!busy && <ArrowRight size={17} />}</button>
          </form>
          <p className="auth-switch">{isRegister ? "Already have an account?" : "New to CampusDesk?"} <Link to={isRegister ? "/login" : "/register"}>{isRegister ? "Sign in" : "Create an account"}</Link></p>
          <p className="auth-terms">By continuing, you agree to use this workspace responsibly.</p>
        </div>
      </section>
    </main>
  );
}

export default AuthShell;
