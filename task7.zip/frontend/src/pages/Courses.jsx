import { useCallback, useEffect, useState } from "react";
import { ArrowRight, BookOpen, Pencil, Plus, Trash2, Users } from "lucide-react";
import Modal from "../components/Modal.jsx";
import { courseApi } from "../services/api.js";

const EMPTY = { name: "", code: "", department: "", description: "" };

export default function Courses() {
  const [courses, setCourses] = useState([]);
  const [editing, setEditing] = useState(null);
  const [formOpen, setFormOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [enrollmentForm, setEnrollmentForm] = useState(null);
  const [studentId, setStudentId] = useState("");
  const [enrollments, setEnrollments] = useState({});

  const load = useCallback(async () => {
    setLoading(true);
    try { setCourses(await courseApi.list()); setError(""); }
    catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const openForm = (course = null) => {
    setFormOpen(true);
    setEditing(course);
    setForm(course ? { name: course.name, code: course.code, department: course.department, description: course.description } : EMPTY);
    setError("");
  };
  const submit = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      if (editing) await courseApi.update(editing.id, form);
      else await courseApi.create(form);
      setFormOpen(false);
      setEditing(null);
      await load();
    } catch (err) { setError(err.message); }
    finally { setSaving(false); }
  };
  const remove = async (course) => {
    if (!window.confirm(`Delete ${course.name}? Enrollments for this course will also be removed.`)) return;
    try { await courseApi.remove(course.id); await load(); }
    catch (err) { setError(err.message); }
  };
  const showEnrollments = async (course) => {
    setError("");
    setEnrollmentForm(course);
    setStudentId("");
    try { setEnrollments({ ...enrollments, [course.id]: await courseApi.enrollments(course.id) }); }
    catch (err) { setError(err.message); }
  };
  const enroll = async (event) => {
    event.preventDefault();
    try {
      await courseApi.enroll(enrollmentForm.id, Number(studentId));
      setEnrollments({ ...enrollments, [enrollmentForm.id]: await courseApi.enrollments(enrollmentForm.id) });
      setStudentId("");
      setError("");
    } catch (err) { setError(err.message); }
  };

  return (
    <>
      <div className="page-heading"><div><span className="eyebrow">LEARNING CATALOG</span><h1>Courses <span className="count-pill">{courses.length}</span></h1><p>Build your catalog and keep course enrollment moving.</p></div><button className="button button-primary" onClick={() => openForm()}><Plus size={17} /> Add course</button></div>
      {error && !formOpen && !enrollmentForm && <div className="alert error-alert" role="alert">{error}</div>}
      {loading ? <div className="panel"><p className="muted-state">Loading courses…</p></div> : courses.length === 0 ? <section className="panel"><div className="empty-state"><span className="empty-icon"><BookOpen size={20} /></span><strong>Your course catalog is ready to grow</strong><p>Create a course to start organizing your campus curriculum.</p><button className="button button-secondary" onClick={() => openForm()}><Plus size={15} /> Add course</button></div></section> : (
        <section className="courses-grid">{courses.map((course, index) => <article className="course-card" key={course.id}><div className={`course-card-art art-${index % 4}`}><span>{course.code}</span><BookOpen size={30} strokeWidth={1.35} /></div><div className="course-card-content"><div className="course-meta"><span>{course.department}</span><div className="row-actions"><button onClick={() => openForm(course)} aria-label={`Edit ${course.name}`}><Pencil size={15} /></button><button className="danger-action" onClick={() => remove(course)} aria-label={`Delete ${course.name}`}><Trash2 size={15} /></button></div></div><h2>{course.name}</h2><p>{course.description || "No course description provided."}</p><button className="course-enroll-link" onClick={() => showEnrollments(course)}><Users size={15} /> Manage enrollment <ArrowRight size={15} /></button></div></article>)}</section>
      )}
      {formOpen && <Modal title={editing ? "Edit course" : "Add a course"} onClose={() => setFormOpen(false)}>
        <form className="data-form" onSubmit={submit}>
          <label>Course name<input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} placeholder="e.g. Introduction to Design" required maxLength="120" /></label>
          <label>Course code<input value={form.code} onChange={(event) => setForm({ ...form, code: event.target.value })} placeholder="e.g. DES-101" required minLength="2" maxLength="30" /></label>
          <label>Department<input value={form.department} onChange={(event) => setForm({ ...form, department: event.target.value })} placeholder="e.g. School of Arts" required maxLength="100" /></label>
          <label>Description <span className="optional-label">OPTIONAL</span><textarea value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} placeholder="A short introduction to this course..." rows="3" maxLength="500" /></label>
          {error && <div className="alert error-alert" role="alert">{error}</div>}
          <div className="form-actions"><button type="button" className="button button-quiet" onClick={() => setFormOpen(false)}>Cancel</button><button className="button button-primary" disabled={saving}>{saving ? "Saving…" : editing ? "Save changes" : "Add course"}</button></div>
        </form>
      </Modal>}
      {enrollmentForm && <Modal title={`Enrollment · ${enrollmentForm.code}`} onClose={() => setEnrollmentForm(null)}>
        <p className="modal-description">{enrollmentForm.name}. Enter a student record ID to enroll that student.</p>
        <form className="enroll-form" onSubmit={enroll}><label>Student ID<input type="number" min="1" value={studentId} onChange={(event) => setStudentId(event.target.value)} placeholder="e.g. 1" required /></label><button className="button button-primary">Enroll student</button></form>
        {error && <div className="alert error-alert" role="alert">{error}</div>}
        <div className="enrollment-list"><strong>Enrolled student IDs</strong>{(enrollments[enrollmentForm.id] || []).length ? (enrollments[enrollmentForm.id] || []).map((item) => <span className="enrollment-item" key={item.id}><span className="small-avatar">{item.student_id}</span> Student #{item.student_id}</span>) : <p className="muted-state">No students enrolled yet.</p>}</div>
      </Modal>}
    </>
  );
}
