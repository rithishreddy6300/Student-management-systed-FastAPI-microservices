import os

import jwt
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from . import models
from .database import Base, engine, get_db
from .schemas import CourseCreate, CourseRead, CourseUpdate, EnrollmentRead


SECRET_KEY = os.getenv("JWT_SECRET_KEY", "")
if len(SECRET_KEY) < 32:
    raise RuntimeError("JWT_SECRET_KEY must be set to at least 32 characters.")
ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
bearer_scheme = HTTPBearer(auto_error=False)
Base.metadata.create_all(bind=engine)
app = FastAPI(title="Course Management Service", version="1.0.0")


def require_user(credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme)):
    if credentials is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required.")
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        if not payload.get("sub"):
            raise ValueError("Token subject is missing.")
    except (jwt.PyJWTError, ValueError):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired access token.") from None


@app.get("/health")
def health():
    return {"status": "ok", "service": "courses"}


@app.post("/courses", response_model=CourseRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_user)])
def create_course(payload: CourseCreate, db: Session = Depends(get_db)):
    course = models.Course(**payload.model_dump())
    db.add(course)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="A course with this name or code already exists.") from None
    db.refresh(course)
    return course


@app.get("/courses", response_model=list[CourseRead], dependencies=[Depends(require_user)])
def list_courses(db: Session = Depends(get_db)):
    return db.scalars(select(models.Course).order_by(models.Course.name)).all()


@app.get("/courses/{course_id}", response_model=CourseRead, dependencies=[Depends(require_user)])
def get_course(course_id: int, db: Session = Depends(get_db)):
    course = db.get(models.Course, course_id)
    if course is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Course not found.")
    return course


@app.put("/courses/{course_id}", response_model=CourseRead, dependencies=[Depends(require_user)])
def update_course(course_id: int, payload: CourseUpdate, db: Session = Depends(get_db)):
    course = db.get(models.Course, course_id)
    if course is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Course not found.")
    for field, value in payload.model_dump().items():
        setattr(course, field, value)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="A course with this name or code already exists.") from None
    db.refresh(course)
    return course


@app.delete("/courses/{course_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(require_user)])
def delete_course(course_id: int, db: Session = Depends(get_db)):
    course = db.get(models.Course, course_id)
    if course is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Course not found.")
    db.delete(course)
    db.commit()


@app.post(
    "/courses/{course_id}/students/{student_id}",
    response_model=EnrollmentRead,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_user)],
)
def enroll_student(course_id: int, student_id: int, db: Session = Depends(get_db)):
    if db.get(models.Course, course_id) is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Course not found.")
    enrollment = models.Enrollment(course_id=course_id, student_id=student_id)
    db.add(enrollment)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Student is already enrolled in this course.") from None
    db.refresh(enrollment)
    return enrollment


@app.get(
    "/courses/{course_id}/students",
    response_model=list[EnrollmentRead],
    dependencies=[Depends(require_user)],
)
def list_enrollments(course_id: int, db: Session = Depends(get_db)):
    if db.get(models.Course, course_id) is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Course not found.")
    return db.scalars(select(models.Enrollment).where(models.Enrollment.course_id == course_id)).all()
