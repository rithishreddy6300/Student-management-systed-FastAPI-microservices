import os

import jwt
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from . import models
from .database import Base, engine, get_db
from .schemas import StudentCreate, StudentRead, StudentUpdate


SECRET_KEY = os.getenv("JWT_SECRET_KEY", "")
if len(SECRET_KEY) < 32:
    raise RuntimeError("JWT_SECRET_KEY must be set to at least 32 characters.")
ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
bearer_scheme = HTTPBearer(auto_error=False)
Base.metadata.create_all(bind=engine)
app = FastAPI(title="Student Management Service", version="1.0.0")


def require_user(credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme)):
    if credentials is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required.")
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        if not payload.get("sub"):
            raise ValueError("Token subject is missing.")
    except (jwt.PyJWTError, ValueError):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired access token.") from None


@app.get("/health")
def health():
    return {"status": "ok", "service": "students"}


@app.post("/students", response_model=StudentRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_user)])
def create_student(payload: StudentCreate, db: Session = Depends(get_db)):
    data = payload.model_dump()
    data["email"] = str(data["email"]).lower()
    student = models.Student(**data)
    db.add(student)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="A student with this email already exists.") from None
    db.refresh(student)
    return student


@app.get("/students", response_model=list[StudentRead], dependencies=[Depends(require_user)])
def list_students(db: Session = Depends(get_db)):
    return db.scalars(select(models.Student).order_by(models.Student.name)).all()


@app.get("/students/{student_id}", response_model=StudentRead, dependencies=[Depends(require_user)])
def get_student(student_id: int, db: Session = Depends(get_db)):
    student = db.get(models.Student, student_id)
    if student is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Student not found.")
    return student


@app.put("/students/{student_id}", response_model=StudentRead, dependencies=[Depends(require_user)])
def update_student(student_id: int, payload: StudentUpdate, db: Session = Depends(get_db)):
    student = db.get(models.Student, student_id)
    if student is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Student not found.")
    data = payload.model_dump()
    data["email"] = str(data["email"]).lower()
    for field, value in data.items():
        setattr(student, field, value)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="A student with this email already exists.") from None
    db.refresh(student)
    return student


@app.delete("/students/{student_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(require_user)])
def delete_student(student_id: int, db: Session = Depends(get_db)):
    student = db.get(models.Student, student_id)
    if student is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Student not found.")
    db.delete(student)
    db.commit()
